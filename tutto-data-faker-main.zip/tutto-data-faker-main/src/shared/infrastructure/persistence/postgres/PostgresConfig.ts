export interface PostgresConfig {
  user: string
  password: string
  database: string
  port: number
  host: string
}
