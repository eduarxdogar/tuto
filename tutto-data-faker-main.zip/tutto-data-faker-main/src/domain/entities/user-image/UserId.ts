import { Uuid } from '@shared/domain/value-object/Uuid'

export class UserImageId extends Uuid {}
