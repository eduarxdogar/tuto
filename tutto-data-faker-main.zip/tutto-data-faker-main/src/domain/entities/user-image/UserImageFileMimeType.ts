import { StringValueObject } from '@shared/domain/value-object/StringValueObject'

export class UserImageFileMimeType extends StringValueObject {}
